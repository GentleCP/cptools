# cptools
我个人写代码过程觉得有用的小工具函数合集

# progress
- download_file(url, session, file_path, overwrite)   
    文件下载进度条，requests库的get方法默认是没有进度条的，使用该函数能够弥补这一点，效果如下图
    ![](img/download-file.png)



