
class CP:

    def __init__(self):
        self.name = 'cp'



def hello():
    print("hello, my name is cp!")